using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class move : MonoBehaviour
{
    float speed = 0.2f;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void AnimatorMove()
    {
        Vector3 startPosition = this.transform.position;
        GameObject chara= GameObject.Find("amiya");
        chara.transform.Translate(speed,-speed,0); //���·���
        Debug.Log("����");
    }
}
