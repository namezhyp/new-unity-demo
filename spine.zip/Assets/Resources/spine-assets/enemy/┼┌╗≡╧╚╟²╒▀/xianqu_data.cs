using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class xianqu_data : MonoBehaviour
{
    public int health = 3000;
    public int attackRange = 16;
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
