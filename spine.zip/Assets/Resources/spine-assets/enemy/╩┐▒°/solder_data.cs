using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class solder_data : MonoBehaviour
{
    public int health = 1500;
    public int attackRange = 3;
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
