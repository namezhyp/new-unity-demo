using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class amiya_data : MonoBehaviour
{
    public int health= 1000;
    public int attackRange= 10;
    public bool chooseable = true;//��Ǹ�����ɷ�ѡ��
    private bool choosing = false;//��ǰ�Ƿ��ڱ�ѡ�е�״̬

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {

    }
}


