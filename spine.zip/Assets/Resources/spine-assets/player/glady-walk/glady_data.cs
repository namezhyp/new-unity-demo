using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class glady_data : MonoBehaviour
{
    public int health = 2000;
    public int attackRange = 15;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
