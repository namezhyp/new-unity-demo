using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class kada_walk : MonoBehaviour
{
    public int health = 12;
    public int attackRange = 15;
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
