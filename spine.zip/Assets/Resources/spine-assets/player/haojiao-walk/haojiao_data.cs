using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class haojiao_data : MonoBehaviour
{
    public int health = 3500;
    public int attackRange = 30;
    public int minattackRange = 12;
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
