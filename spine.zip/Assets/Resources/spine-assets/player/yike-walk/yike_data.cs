using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class yike_data : MonoBehaviour
{
    public int health = 1500;
    public int attackRange = 15;
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
